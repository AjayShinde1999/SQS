package com.sqspublisherconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqsPublisherConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqsPublisherConsumerApplication.class, args);
	}

}
